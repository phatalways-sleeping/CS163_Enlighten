#include "Foo.hpp"

class Foo;
